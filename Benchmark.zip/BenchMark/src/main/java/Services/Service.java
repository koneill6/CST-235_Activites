package Services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

@ManagedBean
public class Service {
	
	String passage = "";
	
	public Service(String passage) {
		this.passage = passage;
	}

	public Service() {
	}

	
	public String getPassage() {
		return passage;
	}

	public void setPassage(String passage) {
		this.passage = passage;
	}


	String dbURL = "jdbc:mysql://localhost:3306/activity1";
	String user = "root";
	String password = "root";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public String onSubmit() throws Exception {
		
		//getting ID from form
		FacesContext context = FacesContext.getCurrentInstance();
		String Book = context.getApplication().evaluateExpressionGet(context, "#{bookID}", String.class);
		int Chapter = context.getApplication().evaluateExpressionGet(context, "#{chapterID}", Integer.class);
		int Verse = context.getApplication().evaluateExpressionGet(context, "#{verseID}", Integer.class);
		
		//creates service object to run DB search
		Service s = new Service();
		
		//created new object to be put in POST request with the found passage
		Service service = new Service(s.getPassage(Book, Chapter, Verse));
		
		//put user object into the POST request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("service", service);
		
		return "Response.xhtml";
	}
	
	public String getPassage(String b, int c, int v) throws SQLException {
		String passage = "";
		//db work
		conn = DriverManager.getConnection(dbURL, user,password);
		System.out.println("Connection is successful");
		
		pstmt = conn.prepareStatement("SELECT * FROM activity1.bible WHERE BOOK=? and CHAPTER=? and VERSE=?");
		pstmt.setString(1, b);
		pstmt.setInt(2, c);
		pstmt.setInt(3, v);
		
		rs = pstmt.executeQuery();
		
		while(rs.next()){
			System.out.println(rs.getString("PASSAGE"));
			passage = rs.getString("PASSAGE");
		}
		
		return passage;
	}

}
